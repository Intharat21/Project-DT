
    $('#confirmDeleteModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget)  // ปุ่มที่เปิด modal
        var empId = button.data('emp-id')    // ดึงค่า ID ของพนักงานจาก data-* attribute
        var deleteUrl = "{{ url_for('delete_employee', emp_id='') }}" + empId;  // สร้าง URL สำหรับลบ

        // อัปเดตปุ่มลบใน modal เพื่อชี้ไปยัง URL ที่ถูกต้อง
        var confirmDeleteButton = $(this).find('#confirmDeleteButton');
        confirmDeleteButton.attr('href', deleteUrl);
    });

