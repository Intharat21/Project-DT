from flask import Flask, render_template, request, redirect, url_for
import pandas as pd

app = Flask(__name__)


@app.route('/')
def index():
    # Read Excel 
    excel_file = 'instance/Prosth-รายการวัสดุนอกเวลาที่ต้องการสั่งซื้อ.xlsx'
    df = pd.read_excel(excel_file)

    # Replace NaN values with an empty string
    df = df.fillna('')

    # Convert the DataFrame 
    DataBase = df.to_dict(orient='records')

    # Pass data to the template
    return render_template('index.html', Data=DataBase)

# Route update data
@app.route('/update_data', methods=['POST'])
def update_data():
    # Read Excel file
    excel_file = 'instance/Prosth-รายการวัสดุนอกเวลาที่ต้องการสั่งซื้อ.xlsx'
    df = pd.read_excel(excel_file)

    # Replace NaN values with empty string
    df = df.fillna('')

    # Get form data and update 
    for i, row in df.iterrows():
        df.at[i, 'Unnamed: 1'] = request.form.get(f'order_{i+1}')
        df.at[i, 'Unnamed: 2'] = request.form.get(f'item_{i+1}')
        df.at[i, 'Unnamed: 3'] = request.form.get(f'unit_{i+1}')
        df.at[i, 'Unnamed: 4'] = request.form.get(f'stock_{i+1}')
        df.at[i, 'Unnamed: 15'] = request.form.get(f'quantity_{i+1}')

    # Write the updated DataFrame back to the Excel file
    df.to_excel(excel_file, index=False)

    return redirect(url_for('index'))

@app.route('/add', methods=['GET', 'POST'])
def add_employee():
    message = ""
    excel_file = 'instance/Prosth-รายการวัสดุนอกเวลาที่ต้องการสั่งซื้อ.xlsx'

    if request.method == 'POST':
        # Read the current Excel data
        df = pd.read_excel(excel_file)
        df = df.fillna('')  # Replace NaN with an empty string

        # Collect new employee data from form fields
        new_data = {
            'Unnamed: 1': request.form['emp_id'],       # Employee ID
            'Unnamed: 2': request.form['name'],         # Name
            'Unnamed: 3': request.form['position'],     # Position
            'Unnamed: 4': request.form['hire_date'],    # Hire Date
            'Unnamed: 15': request.form['no']           # Additional Info/No
        }

        # Check if Employee ID already exists in column 'Unnamed: 1'
        if df['Unnamed: 1'].astype(str).eq(new_data['Unnamed: 1']).any():
            message = "Employee ID already exists. Please use a different ID."
        else:
            # Add new data to the DataFrame
            df = pd.concat([df, pd.DataFrame([new_data])], ignore_index=True)

            # Save the updated DataFrame back to the Excel file
            df.to_excel(excel_file, index=False)
            message = "ทำรายการสำเร็จ!"  # Success message in Thai

        return render_template('add.html', message=message)

    return render_template('add.html', message=message)



@app.route('/edit/<int:row_index>', methods=['GET', 'POST'])
def edit_row(row_index):
    # Read Excel file
    excel_file = 'instance/Prosth-รายการวัสดุนอกเวลาที่ต้องการสั่งซื้อ.xlsx'
    df = pd.read_excel(excel_file)
    df = df.fillna('')

    if request.method == 'POST':
        # Update the specific row 
        df.at[row_index, 'Unnamed: 1'] = request.form['order']
        df.at[row_index, 'Unnamed: 2'] = request.form['item']
        df.at[row_index, 'Unnamed: 3'] = request.form['unit']
        df.at[row_index, 'Unnamed: 4'] = request.form['stock']
        df.at[row_index, 'Unnamed: 15'] = request.form['quantity']

        # Save the updated data back to Excel
        df.to_excel(excel_file, index=False)
        return redirect(url_for('index'))

    # Pass the specific row data to the template
    row_data = df.iloc[row_index].to_dict()
    return render_template('edit_row.html', row_data=row_data, row_index=row_index)




@app.route('/delete/<int:row_index>', methods=['POST'])
def delete_row(row_index):
    excel_file = 'instance/Prosth-รายการวัสดุนอกเวลาที่ต้องการสั่งซื้อ.xlsx'
    df = pd.read_excel(excel_file)
    df = df.fillna('')

    # Drop the row and reset the DataFrame index
    df = df.drop(index=row_index).reset_index(drop=True)

    # Save the updated DataFrame back to the Excel file
    df.to_excel(excel_file, index=False)

    return redirect(url_for('index'))

@app.route('/search', methods=['GET', 'POST'])
def search_employee():
    if request.method == 'POST':
        emp_id = request.form['emp_id']
        excel_file = 'instance/Prosth-รายการวัสดุนอกเวลาที่ต้องการสั่งซื้อ.xlsx'
        df = pd.read_excel(excel_file).fillna('')

        # Filter DataFrame based on the search term
        filtered_df = df[df['Unnamed: 1'].astype(str).str.contains(emp_id, case=False)]

        # Convert the filtered DataFrame to a dictionary format and include the original index
        employees = []
        for i, row in filtered_df.iterrows():
            row_data = row.to_dict()
            row_data['index'] = i  # Add the original index
            employees.append(row_data)

        return render_template('search_result.html', employees=employees)

    return redirect(url_for('index'))



if __name__ == '__main__':
    app.run(debug=True)
